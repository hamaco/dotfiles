#!/bin/bash

echo '################################################'
echo 'Missing files:'
echo '################################################'
for i in `grep .png skin.ini|awk -F= '{print $2}'|awk -F"," '{print $1}'|sed -e 's/ //g'` ; do
        ls $i >/dev/null 2>&1 ||echo $i
done

echo '################################################'
echo 'Unused files:'
echo '################################################'
for i in `find . -name \*.png`; do
        i=`echo $i|sed -e 's/\.\///'`
        grep $i skin.ini >/dev/null 2>&1 ||echo $i
done

echo '################################################'
echo 'Duplicated files:'
echo '################################################'
LIST=`find . -name \*.png|sort|sed -e 's/\.\///'`
for FILE1 in $LIST ; do
   for FILE2 in $LIST; do
      if [[ "$FILE1" < "$FILE2" ]] ; then
         diff $FILE1 $FILE2 >/dev/null && echo -e "$FILE1\t\t$FILE2"
      fi
   done
done
