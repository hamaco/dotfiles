This skin is derived from Tobias Murano's popular Opera skins.
There are no large icons. 

Pizzapops aka Rubot

See more of Tobias's work at http://my.opera.com/tomu/blog/